#!/usr/bin/env python3
"""Build, then run real integration tests. No Docker. Processes stop in test finalizers."""
from pathlib import Path
import datetime
import json
import os
import platform
import subprocess
import sys
import xml.etree.ElementTree as ET

root=Path(__file__).resolve().parents[1]
(root/'var').mkdir(exist_ok=True)
subprocess.run(['mvn','-q','-DskipTests','package'],cwd=root/'business',check=True)
env={**os.environ,'RUN_JAVA_INTEGRATION':'1','PYTHONPATH':str(root/'agent')}
xml=root/'var/test-results.xml'
result=subprocess.run([sys.executable,'-m','pytest','-q','tests','--junitxml='+str(xml)],cwd=root/'agent',env=env)
if xml.exists():
    suite=ET.parse(xml).getroot().find('testsuite')
    report={'checked_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),
            'platform':platform.platform(),'python':platform.python_version(),
            'suite':dict(suite.attrib),'mode':'local Python + Java + SQLite + H2; no Docker',
            'model':'deterministic baseline; HTTP adapter contract tested with local mock',
            'not_executed':['paid model quality evaluation','PostgreSQL deployment','container deployment','GPU inference'],
            'cases':[{'name':t.attrib['name'],'seconds':t.attrib.get('time'),
                      'passed':len(list(t))==0} for t in suite.findall('testcase')]}
    (root/'docs/test-report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2))
raise SystemExit(result.returncode)
