"""Ops Copilot: a runnable reference, with deterministic and real HTTP model adapters."""
