package book.copilot;

import jakarta.validation.Valid;
import jakarta.validation.constraints.*;

public final class Contracts {
    private Contracts() {}
    public record Draft(
        @NotBlank @Pattern(regexp="[a-z][a-z0-9-]{0,39}") String serviceId,
        @Min(1) int serviceVersion,
        @NotBlank @Size(max=300) String title,
        @NotBlank @Size(max=4000) String body,
        @Pattern(regexp="in_app|email") @NotNull String channel) {}
    public record Approval(@Min(1) long expiresAt, @Pattern(regexp="[a-f0-9]{64}") @NotNull String signature) {}
    public record TicketRequest(
        @Pattern(regexp="ticket:[a-f0-9-]{36}") @NotNull String actionId,
        @Valid @NotNull Draft draft, @Valid @NotNull Approval approval) {}
}
