# Ops Copilot：从支付告警到可审计工单

面向会 Python、具有 Java 后端经验的工程师。这是按真实运维工作流实现的**完整本地参考项目**：业务数据为明确标注的合成样本，工单确实写入本地 Java/H2 数据库，没有连接生产监控、真实邮件或真实工单平台。

默认 `deterministic` 是可重复的规则策略基线，**不是大模型**。`http` 模式提供真实兼容模型 HTTP 调用代码，需要你指定模型服务；交付验证没有消费付费模型额度。

## 环境与第一次运行

需要 Python 3.11+、JDK 17+；重新构建 Java 还需要 Maven 3.6.3+。已在 Python 3.13、JDK 17、Maven 3.9 环境验证。首次安装 Python 包需要网络。无需 Docker、Redis 或外部数据库。

```sh
python3 -m venv .venv
source .venv/bin/activate
python -m pip install -r agent/requirements.lock
python scripts/dev.py
```

启动器只在你执行时运行 Java、Python API 和 Worker 三个本地子进程，监听 `127.0.0.1`，不自动打开浏览器。按 Ctrl+C 一并关闭。业务 API 为 `http://127.0.0.1:18081`，Agent API 文档为 `http://127.0.0.1:18000/docs`。包内有编译好的 Java JAR 时不必运行 Maven；源码修改后应重新构建并使用新 JAR。

在另一个终端激活同一虚拟环境，然后：

```sh
python scripts/demo.py
python scripts/demo.py --approve
python scripts/demo.py --service inventory
```

第一条只生成草案并打印摘要 hash；第二条明确允许提交本地示例工单；第三条因缺少手册证据进入 `needs_input`。三次命令产生独立 run，第二次不会批准第一次 run。`email` 仅为工单字段，本项目不发邮件。

## 完整验证

```sh
python scripts/check.py
```

命令先构建 Java，然后使用随机空闲本地端口、临时数据库启动真实 Python/Java HTTP 服务。测试结束时关闭全部子进程。覆盖身份、版本、幂等、并发、SSE 重放、Memory 生命周期，以及 Java 提交成功后的真实 Worker 进程退出与恢复。报告见 `docs/test-report.json`；每次执行重写该报告。

只跑不依赖 Java 的核心测试：

```sh
cd agent
../.venv/bin/python -m pytest -q tests/test_core.py
```

## 代码入口

| 能力 | 完整文件 |
| --- | --- |
| API、审批、取消、SSE、监控指标 | `agent/copilot/api.py` |
| Agent 单步执行、重试和业务提交 | `agent/copilot/worker.py` |
| SQLite 事务、租约与 fencing | `agent/copilot/store.py` |
| 显式记忆、版本、过期、删除和 outbox | `agent/copilot/memory.py` |
| 规则基线与真实 HTTP 模型适配器 | `agent/copilot/model.py` |
| 版本化文档摄入与权限过滤 | `agent/copilot/knowledge.py` |
| Java 原子幂等、签名与资源版本检查 | `business/src/main/java/book/copilot/TicketService.java` |
| 跨服务 HTTP 与崩溃演练 | `agent/tests/test_integration.py` |

架构和逐行导读配套在知识博客的“项目实战”部分。原来的概念伪代码保留用于解释；上表中的文件才是可直接运行的参考实现。

## 数据与配置

本地运行数据在 `var/`。Agent 状态使用 SQLite WAL，Java 业务真源使用 H2 文件数据库。两者没有分布式事务，通过稳定 `action_id`、Java 原子写入和重复查询收敛。

复制 `.env.example` 为 `.env` 可设置模型和示例身份；`dev.py` 读取它，但不会执行其中的脚本。默认凭据只用于本机练习。共享部署前需替换为真实认证、凭据管理和服务身份。数据库备份应使用 `scripts/backup.py`，不要在有 WAL 写入时只复制一个 `.db` 文件。

```sh
python scripts/backup.py var/copilot.db var/backups/copilot-snapshot.db
python scripts/capacity.py --arrival-rps 2 --mean-seconds 6
```

## 部署边界

`compose.yaml` 和 `infra/Dockerfile.*` 是可审查的单机容器配置，**交付时没有启动或验证 Docker 部署**。本机版本不能仅靠“加副本”变成多机系统；SQLite 不能放到共享网络文件系统。`infra/postgres-queue.sql` 是待实现 PostgreSQL 适配器的设计参考，参数占位符需由驱动绑定，不能直接当作现成迁移运行。

已实现：本地持久运行、租约 fencing、审批摘要、原子业务幂等、显式 Memory、基础权限、版本化检索、事件流与实际集成测试。

尚未实现：企业 SSO、向量检索/重排、GPU 推理服务、分布式 token 配额、完整 OpenTelemetry 管道、真实监控接入、自动生产修复。博客讲明了这些扩展如何设计、迁移和验收，不把它们计入已运行成果。
